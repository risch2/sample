
1) Import this file to your IDE
2) before first run clean the project 
3) run it
4) it will ask for ZIP CODE enter [94133,94133] [94200,94299] [94600,94699] for 1st test case
5) run it again and put [94133,94133] [94200,94299] [94266,94399] for 2nd test case
