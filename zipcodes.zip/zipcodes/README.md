1) Import this file to your IDE
2) before first run clean the project 
3) run it
4) it will ask for ZIP CODE enter [94133,94133] [94200,94299] [94600,94699] for 1st test case
5) run it again and put [94133,94133] [94200,94299] [94266,94399] for 2nd test case
6) 4 Unit Test included which cover all the validate input
7) Decompose of objects
  a) MainClass.java is for run main method of java to take input and call another class as per needed
  b) ZipcodeGetterSetter.java is encapsulate class
  c) ZipcodeComparator.java to compare range by inbuilt java collection framework
  d) ZipcodeMerger.java is to sort and merge the zip code list
  e) ZipcodeProcessor.java is for validating input received from user